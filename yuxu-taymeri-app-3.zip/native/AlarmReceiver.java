package az.yuxu.taymeri;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context ctx, Intent intent) {
    ContextCompat.startForegroundService(ctx, new Intent(ctx, AlarmService.class));
  }
}
