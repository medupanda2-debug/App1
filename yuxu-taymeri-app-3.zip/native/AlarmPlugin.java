package az.yuxu.taymeri;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.provider.Settings;
import androidx.activity.result.ActivityResult;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "YuxuAlarm")
public class AlarmPlugin extends Plugin {
  private static MediaPlayer pv;

  private android.content.SharedPreferences prefs() {
    return getContext().getSharedPreferences("yuxu", 0);
  }

  private PendingIntent alarmPi() {
    Intent i = new Intent(getContext(), AlarmReceiver.class).setAction("az.yuxu.taymeri.ALARM");
    return PendingIntent.getBroadcast(getContext(), 1, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  private boolean notifOk() { return NotificationManagerCompat.from(getContext()).areNotificationsEnabled(); }
  private boolean overlayOk() { return Settings.canDrawOverlays(getContext()); }
  private boolean fsOk() {
    if (Build.VERSION.SDK_INT >= 34) {
      NotificationManager nm = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
      return nm.canUseFullScreenIntent();
    }
    return true;
  }

  private JSObject info() {
    JSObject o = new JSObject();
    o.put("name", prefs().getString("name", "Sistem alarm səsi (standart)"));
    o.put("notif", notifOk());
    o.put("overlay", overlayOk());
    o.put("fullscreen", fsOk());
    return o;
  }

  @PluginMethod
  public void getInfo(PluginCall call) { call.resolve(info()); }

  @PluginMethod
  public void schedule(PluginCall call) {
    Double at = call.getDouble("at");
    if (at == null) { call.reject("at yoxdur"); return; }
    long t = at.longValue();
    if (t > System.currentTimeMillis()) {
      AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
      Intent show = new Intent(getContext(), MainActivity.class);
      PendingIntent showPi = PendingIntent.getActivity(getContext(), 2, show,
          PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
      am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, showPi), alarmPi());
    }
    call.resolve();
  }

  @PluginMethod
  public void stop(PluginCall call) {
    AlarmManager am = (AlarmManager) getContext().getSystemService(Context.ALARM_SERVICE);
    am.cancel(alarmPi());
    getContext().stopService(new Intent(getContext(), AlarmService.class));
    final Activity a = getActivity();
    if (a != null) a.runOnUiThread(() -> { try { a.stopLockTask(); } catch (Exception e) {} });
    call.resolve();
  }

  @PluginMethod
  public void isRinging(PluginCall call) {
    JSObject o = new JSObject();
    o.put("ringing", AlarmService.ringing);
    call.resolve(o);
  }

  @PluginMethod
  public void requestNext(PluginCall call) {
    String next = "";
    String pkg = getContext().getPackageName();
    try {
      if (!notifOk()) {
        next = "notif";
        if (Build.VERSION.SDK_INT >= 33) {
          ActivityCompat.requestPermissions(getActivity(), new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
        } else {
          Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
          getActivity().startActivity(i);
        }
      } else if (!overlayOk()) {
        next = "overlay";
        getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + pkg)));
      } else if (!fsOk()) {
        next = "fullscreen";
        getActivity().startActivity(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + pkg)));
      }
    } catch (Exception e) {}
    JSObject o = new JSObject();
    o.put("next", next);
    call.resolve(o);
  }

  @PluginMethod
  public void pickSound(PluginCall call) {
    String kind = call.getString("kind", "system");
    if ("reset".equals(kind)) {
      prefs().edit().clear().apply();
      call.resolve(info());
      return;
    }
    Intent i;
    if ("file".equals(kind)) {
      i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
      i.addCategory(Intent.CATEGORY_OPENABLE);
      i.setType("audio/*");
      i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    } else {
      i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
      i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL);
      i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
      i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false);
      i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Alarm səsi");
      String cur = prefs().getString("uri", null);
      if (cur != null) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur));
    }
    startActivityForResult(call, i, "pickResult");
  }

  @ActivityCallback
  private void pickResult(PluginCall call, ActivityResult r) {
    if (call == null) return;
    if (r.getResultCode() != Activity.RESULT_OK || r.getData() == null) { call.resolve(info()); return; }
    Intent d = r.getData();
    Uri u;
    String name = null;
    if (d.hasExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)) {
      u = (Uri) d.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
    } else {
      u = d.getData();
      if (u != null) {
        try { getContext().getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) {}
        name = queryName(u);
      }
    }
    if (u == null) { call.resolve(info()); return; }
    if (name == null) {
      try {
        Ringtone rt = RingtoneManager.getRingtone(getContext(), u);
        name = rt.getTitle(getContext());
      } catch (Exception e) { name = "Seçilmiş səs"; }
    }
    prefs().edit().putString("uri", u.toString()).putString("name", name).apply();
    call.resolve(info());
  }

  private String queryName(Uri u) {
    try (Cursor c = getContext().getContentResolver().query(u, null, null, null, null)) {
      if (c != null && c.moveToFirst()) {
        int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
        if (idx >= 0) return c.getString(idx);
      }
    } catch (Exception e) {}
    return null;
  }

  @PluginMethod
  public void preview(PluginCall call) {
    try {
      if (pv != null) {
        try { pv.stop(); } catch (Exception e) {}
        pv.release();
        pv = null;
      } else {
        pv = AlarmService.build(getContext(), false);
        if (pv != null) {
          pv.setOnCompletionListener(m -> { m.release(); pv = null; });
          pv.start();
          new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (pv != null) { try { pv.stop(); pv.release(); } catch (Exception e) {} pv = null; }
          }, 6000);
        }
      }
    } catch (Exception e) { pv = null; }
    call.resolve();
  }
}
