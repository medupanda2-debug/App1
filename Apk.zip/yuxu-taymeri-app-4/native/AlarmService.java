package az.yuxu.taymeri;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;
import java.util.List;

public class AlarmService extends Service {
  static volatile boolean ringing = false;
  static volatile String ringTitle = "", ringText = "";
  private MediaPlayer mp;
  private Vibrator vib;
  private PowerManager.WakeLock wl;

  static MediaPlayer build(Context c, boolean loop) {
    List<Uri> l = new ArrayList<>();
    String s = c.getSharedPreferences("yuxu", 0).getString("uri", null);
    if (s != null) l.add(Uri.parse(s));
    l.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
    l.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE));
    l.add(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION));
    for (Uri u : l) {
      try {
        MediaPlayer m = new MediaPlayer();
        m.setAudioAttributes(new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        m.setDataSource(c, u);
        m.setLooping(loop);
        m.prepare();
        return m;
      } catch (Exception e) {}
    }
    return null;
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent != null && "STOP".equals(intent.getAction())) {
      stopSelf();
      return START_NOT_STICKY;
    }
    String lb = intent != null ? intent.getStringExtra("label") : null;
    boolean isAlarm = intent != null && intent.getBooleanExtra("alarm", false);
    String title = isAlarm ? "⏰ Alarm" : "🌅 Oyanma vaxtı!";
    String text = (lb != null && !lb.isEmpty()) ? lb : (isAlarm ? "Alarm vaxtı gəldi" : "Yuxu taymeri bitdi");
    ringTitle = title;
    ringText = text;
    ringing = true;
    String ch = "yuxu_alarm_v2";
    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(ch, "Yuxu alarmı", NotificationManager.IMPORTANCE_HIGH);
      c.setSound(null, null);
      c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
      nm.createNotificationChannel(c);
    }
    Intent open = new Intent(this, MainActivity.class)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP)
        .putExtra("alarm", true);
    int f = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
    PendingIntent openPi = PendingIntent.getActivity(this, 3, open, f);
    PendingIntent stopPi = PendingIntent.getService(this, 4, new Intent(this, AlarmService.class).setAction("STOP"), f);
    Notification n = new NotificationCompat.Builder(this, ch)
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle(title)
        .setContentText(text)
        .setCategory(NotificationCompat.CATEGORY_ALARM)
        .setPriority(NotificationCompat.PRIORITY_MAX)
        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        .setOngoing(true)
        .setContentIntent(openPi)
        .setFullScreenIntent(openPi, true)
        .addAction(0, "Dayandır", stopPi)
        .build();
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    } else {
      startForeground(1, n);
    }

    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
    wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yuxu:alarm");
    wl.acquire(6 * 60 * 60 * 1000L);

    try {
      AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
      int max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM);
      if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max * 0.7) {
        am.setStreamVolume(AudioManager.STREAM_ALARM, (int) (max * 0.7), 0);
      }
    } catch (Exception e) {}

    if (mp == null) {
      mp = build(this, true);
      if (mp != null) mp.start();
    }
    try {
      vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
      long[] pat = {0, 600, 400, 600, 400};
      if (Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createWaveform(pat, 0));
      else vib.vibrate(pat, 0);
    } catch (Exception e) {}

    try { startActivity(open); } catch (Exception e) {}
    return START_NOT_STICKY;
  }

  @Override
  public void onDestroy() {
    ringing = false;
    try { if (mp != null) { mp.stop(); mp.release(); } } catch (Exception e) {}
    mp = null;
    try { if (vib != null) vib.cancel(); } catch (Exception e) {}
    try { if (wl != null && wl.isHeld()) wl.release(); } catch (Exception e) {}
    stopForeground(true);
    super.onDestroy();
  }

  @Override
  public IBinder onBind(Intent i) { return null; }
}
