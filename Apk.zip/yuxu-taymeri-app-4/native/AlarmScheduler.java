package az.yuxu.taymeri;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONObject;

public class AlarmScheduler {
  static SharedPreferences p(Context c) { return c.getSharedPreferences("yuxu", 0); }

  static PendingIntent pi(Context c, int id, String label) {
    Intent i = new Intent(c, AlarmReceiver.class).setAction("az.yuxu.taymeri.ALARM")
        .putExtra("alarmId", id).putExtra("label", label == null ? "" : label);
    return PendingIntent.getBroadcast(c, 1000 + id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
  }

  static JSONArray load(Context c) {
    try { return new JSONArray(p(c).getString("alarms", "[]")); } catch (Exception e) { return new JSONArray(); }
  }

  static void cancelAll(Context c, JSONArray arr) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    for (int i = 0; i < arr.length(); i++) {
      JSONObject o = arr.optJSONObject(i);
      if (o != null) am.cancel(pi(c, o.optInt("id"), o.optString("label")));
    }
  }

  static void save(Context c, JSONArray fresh) {
    cancelAll(c, load(c));
    p(c).edit().putString("alarms", fresh.toString()).apply();
    scheduleAll(c);
  }

  static long next(JSONObject a) {
    long now = System.currentTimeMillis();
    JSONArray days = a.optJSONArray("days");
    for (int add = 0; add < 8; add++) {
      Calendar c = Calendar.getInstance();
      c.add(Calendar.DAY_OF_YEAR, add);
      c.set(Calendar.HOUR_OF_DAY, a.optInt("h"));
      c.set(Calendar.MINUTE, a.optInt("m"));
      c.set(Calendar.SECOND, 0);
      c.set(Calendar.MILLISECOND, 0);
      if (c.getTimeInMillis() <= now) continue;
      if (days == null || days.length() == 0) return c.getTimeInMillis();
      int dow = c.get(Calendar.DAY_OF_WEEK) - 1;
      for (int i = 0; i < days.length(); i++) if (days.optInt(i, -1) == dow) return c.getTimeInMillis();
    }
    return -1;
  }

  static void scheduleAll(Context c) {
    AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
    JSONArray arr = load(c);
    for (int i = 0; i < arr.length(); i++) {
      JSONObject o = arr.optJSONObject(i);
      if (o == null || !o.optBoolean("on")) continue;
      long t = next(o);
      if (t < 0) continue;
      PendingIntent show = PendingIntent.getActivity(c, 2, new Intent(c, MainActivity.class),
          PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
      am.setAlarmClock(new AlarmManager.AlarmClockInfo(t, show), pi(c, o.optInt("id"), o.optString("label")));
    }
  }

  static void onFired(Context c, int id) {
    JSONArray arr = load(c);
    boolean changed = false;
    for (int i = 0; i < arr.length(); i++) {
      JSONObject o = arr.optJSONObject(i);
      if (o != null && o.optInt("id") == id) {
        JSONArray d = o.optJSONArray("days");
        if (d == null || d.length() == 0) {
          try { o.put("on", false); changed = true; } catch (Exception e) {}
        }
      }
    }
    if (changed) p(c).edit().putString("alarms", arr.toString()).apply();
    scheduleAll(c);
  }
}
