package az.yuxu.taymeri;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle s) {
    registerPlugin(AlarmPlugin.class);
    super.onCreate(s);
    alarmFlags(getIntent());
  }

  @Override
  public void onNewIntent(Intent i) {
    super.onNewIntent(i);
    setIntent(i);
    alarmFlags(i);
  }

  @Override
  public void onResume() {
    super.onResume();
    if (!AlarmService.ringing) {
      try { stopLockTask(); } catch (Exception e) {}
    }
  }

  private void alarmFlags(Intent i) {
    if (i == null || !i.getBooleanExtra("alarm", false)) return;
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true);
      setTurnScreenOn(true);
    }
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
    try { startLockTask(); } catch (Exception e) {}
  }
}
