package az.yuxu.taymeri;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context ctx, Intent intent) {
    int id = intent.getIntExtra("alarmId", -1);
    if (id >= 0) AlarmScheduler.onFired(ctx, id);
    Intent s = new Intent(ctx, AlarmService.class)
        .putExtra("label", intent.getStringExtra("label"))
        .putExtra("alarm", id >= 0);
    ContextCompat.startForegroundService(ctx, s);
  }
}
